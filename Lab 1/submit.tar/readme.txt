vim ls_com.txt
ls ~/* > ls_out.txt
gcc -Wall -std=c99 hello.c hello
./hello
tar -cf submit.tar check ls_com.txt ls_out.txt hello.c readme.txt 
